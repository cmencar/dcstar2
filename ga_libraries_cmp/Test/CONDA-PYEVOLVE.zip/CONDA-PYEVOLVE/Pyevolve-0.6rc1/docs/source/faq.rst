
F.A.Q.
====================================

**What is Pyevolve ?**

   Pyevolve is an Evolutionary Computation framework written in pure python.

**Why you have created this framework ?**

   Python is a powerful language, the features of Python together 
   with the Evolutionary Algorithms (EA) can be very interesting. There
   is no good GA library written in Python today, the main effort
   of the Pyevolve is to sane this problem, since the Evolutionary Computation
   research field is growing faster.
