Required Installations
**********************

Python 2.7
===========

This package requires python 2.7 and will not work with python 2.6.
It can easily be transformed into python 2.6 compliant code. Most of the incompatibilities come from list/dict comprehension expressions

PyGame (and all its dependencies)
=================================

Used in visualization of the included TSP solver

pycontract
==========

Used for contract checking (only when testmode is True; see the documentation for settings.py)
